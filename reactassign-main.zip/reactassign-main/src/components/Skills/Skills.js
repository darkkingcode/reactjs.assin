import React from 'react';
import './Skills.css'
function Skills(){
    return(
        <div className='skill'>
            <h1 className='skill-btn'>skills</h1>
            <div className='skill-item'>
               {/* <ul className='skill-ul'>
                    <li className='skill-li'>Python</li>
                    <li className='skill-li'>SQL</li>
                    <li className='skill-li'>C++</li>
                </ul>
                <ul className='skill-ul'>
                    <li className='skill-li'>MS Excel</li>
                    <li className='skill-li'>Linux OS</li>
                    <li className='skill-li'>Java</li>
                </ul>
                <ul className='skill-ul'>
                    <li className='skill-li'>HTML</li>
                    <li className='skill-li'>CSS</li>
                    <li className='skill-li'>JavaScript</li>
    </ul> */}
                <h5 className='skill-li'>SQL</h5>
                <h5 className='skill-li'>Python</h5>
                <h5 className='skill-li'>C++</h5>
                <h5 className='skill-li'>Ms Excel</h5>
                <h5 className='skill-li'>Linux OS</h5>
                <h5 className='skill-li'>Java</h5>
                <h5 className='skill-li'>HTML</h5>
                <h5 className='skill-li'>CSS</h5>
                <h5 className='skill-li'>JavaScript</h5>


            </div>
        </div>
    ); 
}
export default Skills;