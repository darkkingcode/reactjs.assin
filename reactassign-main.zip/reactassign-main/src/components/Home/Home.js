import React from 'react';
import './Home.css';
function Home()
{
    return(
        <div className='home-bar'>
            <div className='home-btn'>
                    <div className='para-head'>
                        <h3>Hi , My name is 'Karthik'</h3>
                        <h3>I'm the software developer</h3>
                    </div>
                   
            </div>
        </div>
    );
}
export default Home;